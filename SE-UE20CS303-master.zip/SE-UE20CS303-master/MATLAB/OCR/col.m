re = imread('co.bmp');
imview(re)
[fl1 rq]=columns(re);
imview(fl1);
